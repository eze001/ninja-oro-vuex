<template>
    <div id="Lugar">
        <p>{{sitio}}</p>
        <p>{{informacion}}</p>
        <button v-on:click="presionar()">Encontrar oro</button>
    </div>
</template>

<script>
    export default {
        name:"Lugar",
        props:{
            sitio:String,
            informacion:String,
        },
        methods:{
            presionar(){
                return this.$store.commit("encontrar", this.sitio);
            },
        }
    }
</script>

<style scoped>
    #Lugar{
        border:3px solid black;
        width:180px;
        height:180px;
        display:inline-block;
        margin:5px;
        padding:20px;
    }
    p,button{
        display:block;
    }
</style>