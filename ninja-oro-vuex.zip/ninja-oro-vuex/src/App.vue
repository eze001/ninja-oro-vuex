<template>
  <div id="app">
    <div class="contorno">
      <h2 :class="{negro:conteo>=0,rojo:conteo<0}">Tu oro: {{conteo}}</h2>
    </div>
    <div class="contorno">
      <Lugar sitio="granja" informacion="Gana 10-20 de oro"/>
      <Lugar sitio="cueva" informacion="Gana 5-10 de oro"/>
      <Lugar sitio="casa" informacion="Gana 2-5 de oro"/>
      <Lugar sitio="casino" informacion="Gana de 0-50 de oro"/>
    </div>
    <div class="contorno">
      <ul>
        <li v-for="(act,index) in agenda" :key="index"><span :class="{verde:cadena[index]>=0,rojo:cadena[index]<0}">{{act}}</span></li>
      </ul>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Lugar from './components/Lugar.vue';

export default {
  name: 'App',
  components: {
    Lugar
  },
  computed: {
    ...mapGetters(["conteo","agenda","cadena"])
  }
}
</script>

<style scoped>
  #app{
    margin:10px;
  }
  .negro{
    color:black;
  }
  .rojo{
    color:red;
  }
  .verde{
    color:green;
  }
  .contorno{
    margin:20px;
  }
</style>
